"use client";

import * as React from "react";
import type { FC } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Trash2, Calculator, Settings, Package, Percent, DollarSign, Download } from "lucide-react";
import { Label } from "@/components/ui/label";
import type { QuoteFormData, QuoteDiscount, DiscountApproval, QuoteApproval, QuoteEmail, QuoteSubmission } from "@/types";
import type { OtherQty } from "@/lib/quote-pdf";

const currency = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
    n
  );

interface Step5Props {
  formData: QuoteFormData;
  setFormData: React.Dispatch<React.SetStateAction<QuoteFormData>>;
  otherQuantities: OtherQty[];
  setOtherQuantities: React.Dispatch<React.SetStateAction<OtherQty[]>>;
  onOpenSave: () => void;
  isEditMode?: boolean;
  selectedQuoteId?: string | null;
}

const Step5Quotation: FC<Step5Props> = ({
  formData,
  setFormData,
  otherQuantities,
  setOtherQuantities,
  onOpenSave,
}) => {
  // State for included/excluded products
  const [includedProducts, setIncludedProducts] = React.useState<Set<number>>(
    new Set(formData.products.map((_, index) => index))
  );

  // Validation state
  const [validationErrors, setValidationErrors] = React.useState<string[]>([]);

  // Discount state
  const [discount, setDiscount] = React.useState<QuoteDiscount>({
    isApplied: false,
    percentage: 0,
    amount: 0,
  });

  // Discount approval state
  const [discountApproval, setDiscountApproval] = React.useState<DiscountApproval>({
    approvedBy: '',
    reason: '',
    approvedAt: new Date(),
  });

  // Quote approval state
  const [quoteApproval, setQuoteApproval] = React.useState<QuoteApproval>({
    status: 'Draft'
  });

  // Quote email state
  const [quoteEmail, setQuoteEmail] = React.useState<QuoteEmail>({
    to: formData.client.email || '',
    cc: formData.client.emails ? JSON.parse(formData.client.emails) : [],
    subject: `Printing Quote - ${formData.client.companyName || 'Your Company'}`,
    body: 'Please find attached our quote for your printing requirements.',
    attachments: {
      customerCopy: true,
      operationsCopy: false
    }
  });

  // Quote submission action
  const [submissionAction, setSubmissionAction] = React.useState<QuoteSubmission['action']>('Save Draft');

  // Available approvers (this could come from user management or be hardcoded)
  const availableApprovers = [
    'Manager',
    'Director',
    'CEO',
    'Finance Manager',
    'Sales Manager'
  ];

  // Sync discount data with form data
  React.useEffect(() => {
    if (formData.calculation.discount) {
      setDiscount(formData.calculation.discount);
      if (formData.calculation.discount.approval) {
        setDiscountApproval(formData.calculation.discount.approval);
      }
    }
  }, [formData.calculation.discount]);

  // Recalculate discount amount when percentage changes
  React.useEffect(() => {
    if (discount.isApplied && discount.percentage > 0) {
      const currentGrandTotal = calculateGrandTotalWithoutDiscount();
      const amount = (currentGrandTotal * discount.percentage) / 100;
      setDiscount(prev => ({
        ...prev,
        amount
      }));
    }
  }, [discount.percentage, discount.isApplied, includedProducts]);

  // Validate form data before allowing save
  const validateFormData = () => {
    const errors: string[] = [];

    // Check if client information is complete
    if (!formData.client.email || !formData.client.phone) {
      errors.push("Client email and phone are required");
    }

    if (formData.client.clientType === "Company" && !formData.client.companyName) {
      errors.push("Company name is required for company clients");
    }

    if (!formData.client.contactPerson && (!formData.client.firstName || !formData.client.lastName)) {
      errors.push("Contact person name is required");
    }

    // Check if products are selected
    if (includedProducts.size === 0) {
      errors.push("At least one product must be selected");
    }

    // Check if products have required information
    formData.products.forEach((product, index) => {
      if (includedProducts.has(index)) {
        if (!product.productName || !product.quantity) {
          errors.push(`Product ${index + 1} must have a name and quantity`);
        }
      }
    });

    // Validate discount approval if discount is applied
    if (discount.isApplied && discount.percentage > 0) {
      if (!discountApproval.approvedBy) {
        errors.push("Discount approver must be selected when applying discount");
      }
      if (!discountApproval.reason.trim()) {
        errors.push("Reason for discount is required when applying discount");
      }
    }

    setValidationErrors(errors);
    return errors.length === 0;
  };

  // Enhanced save function with validation
  const handleSaveWithValidation = () => {
    if (validateFormData()) {
      // Sync discount data with form data before saving
      const updatedFormData = {
        ...formData,
        calculation: {
          ...formData.calculation,
          marginPercentage: 15,
          discount: discount.isApplied ? {
            ...discount,
            approval: discountApproval.approvedBy && discountApproval.reason ? discountApproval : undefined
          } : undefined,
          finalSubtotal: summaryTotals.finalTotal
        },
        // Add approval and email data based on submission action
        approval: submissionAction === 'Send for Approval' ? {
          status: 'Pending Approval' as const,
          approvalNotes: quoteApproval.approvalNotes
        } : submissionAction === 'Send to Customer' ? {
          status: 'Approved' as const
        } : {
          status: 'Draft' as const
        },
        email: submissionAction === 'Send to Customer' ? quoteEmail : undefined
      };
      
      // Update the form data with all information
      setFormData(updatedFormData);
      
      // Log the action being taken
      console.log(`Quote ${submissionAction.toLowerCase()}:`, updatedFormData);
      
      onOpenSave();
    } else {
      console.error('Validation errors:', validationErrors);
    }
  };

  // Calculate comprehensive costs for each product
  const calculateProductCosts = (productIndex: number) => {
    const product = formData.products[productIndex];
    if (!product || !product.quantity) return { 
      paperCost: 0, 
      platesCost: 0, 
      finishingCost: 0, 
      subtotal: 0, 
      margin: 0,
      marginAmount: 0,
      vat: 0, 
      total: 0 
    };

    // 1. Paper Costs
    const paperCost = formData.operational.papers.reduce((total, p) => {
      const pricePerSheet = (p.pricePerPacket || 0) / (p.sheetsPerPacket || 1);
      const actualSheetsNeeded = p.enteredSheets || 0;
      return total + (pricePerSheet * actualSheetsNeeded);
    }, 0);

    // 2. Plates Cost (per plate, typically $25-50 per plate)
    const PLATE_COST_PER_PLATE = 35; // Standard plate cost
    const platesCost = (formData.operational.plates || 0) * PLATE_COST_PER_PLATE;

    // 3. Finishing Costs (cost per unit × actual units needed)
    const actualUnitsNeeded = formData.operational.units || product.quantity || 0;
    const finishingCost = formData.operational.finishing.reduce((total, f) => {
      if (product.finishing.includes(f.name)) {
        return total + ((f.cost || 0) * actualUnitsNeeded);
      }
      return total;
    }, 0);

    // 4. Calculate subtotal, margin, and VAT
    const subtotal = paperCost + platesCost + finishingCost;
    const marginPercentage = 15; // 15% margin
    const marginAmount = subtotal * (marginPercentage / 100);
    const total = subtotal + marginAmount;
    const vat = total * 0.05; // 5% VAT on total including margin
    const finalTotal = total + vat;

    return {
      paperCost,
      platesCost,
      finishingCost,
      subtotal,
      margin: marginPercentage,
      marginAmount,
      vat,
      total: finalTotal
    };
  };

  // Calculate grand total based on included products
  const calculateGrandTotal = () => {
    let total = 0;
    includedProducts.forEach((index) => {
      const costs = calculateProductCosts(index);
      total += costs.total;
    });
    
    // Apply discount if enabled
    if (discount.isApplied && discount.percentage > 0) {
      const discountAmount = total * (discount.percentage / 100);
      total -= discountAmount;
    }
    
    return total;
  };

  // Calculate grand total without discount for percentage calculation
  const calculateGrandTotalWithoutDiscount = () => {
    let total = 0;
    includedProducts.forEach((index) => {
      const costs = calculateProductCosts(index);
      total += costs.total;
    });
    return total;
  };

  // Calculate summary totals for all included products
  const calculateSummaryTotals = () => {
    let totalPaperCost = 0;
    let totalPlatesCost = 0;
    let totalFinishingCost = 0;
    let totalSubtotal = 0;
    let totalMargin = 0;
    let totalMarginAmount = 0;
    let totalVAT = 0;
    let grandTotal = 0;

    includedProducts.forEach((index) => {
      const costs = calculateProductCosts(index);
      totalPaperCost += costs.paperCost;
      totalPlatesCost += costs.platesCost;
      totalFinishingCost += costs.finishingCost;
      totalSubtotal += costs.subtotal;
      totalMarginAmount += costs.marginAmount;
      totalVAT += costs.vat;
      grandTotal += costs.total;
    });

    // Apply discount if enabled
    let finalTotal = grandTotal;
    let discountAmount = 0;
    if (discount.isApplied && discount.percentage > 0) {
      discountAmount = grandTotal * (discount.percentage / 100);
      finalTotal = grandTotal - discountAmount;
    }

    return {
      totalPaperCost,
      totalPlatesCost,
      totalFinishingCost,
      totalSubtotal,
      totalMargin: 15, // 15% margin
      totalMarginAmount,
      totalVAT,
      grandTotal,
      discountAmount,
      finalTotal
    };
  };

  // Handle product inclusion/exclusion
  const toggleProductInclusion = (productIndex: number) => {
    const newIncluded = new Set(includedProducts);
    if (newIncluded.has(productIndex)) {
      newIncluded.delete(productIndex);
    } else {
      newIncluded.add(productIndex);
    }
    setIncludedProducts(newIncluded);
  };

  // Add other quantity with product selection
  const addOtherQty = (): void => {
    const availableProducts = formData.products.filter((_, index) => includedProducts.has(index));
    if (availableProducts.length === 0) return;

    const selectedProduct = availableProducts[0];
    const initialQuantity = 250;
    
    // Calculate initial price
    const initialPrices = calculateOtherQtyPrice({
      productName: selectedProduct.productName,
      quantity: initialQuantity,
      price: 0
    });
    
    setOtherQuantities((prev) => [
      ...prev,
      {
        productName: selectedProduct.productName,
        quantity: initialQuantity,
        price: initialPrices.base, // Set calculated price
      },
    ]);
  };

  // Remove other quantity
  const removeOtherQty = (idx: number): void =>
    setOtherQuantities((prev) => prev.filter((_, i) => i !== idx));

  // Update other quantity
  const updateOtherQty = (idx: number, patch: Partial<OtherQty>): void =>
    setOtherQuantities((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], ...patch };
      
      // Auto-calculate price when quantity changes
      if (patch.quantity !== undefined || patch.productName !== undefined) {
        const updatedQty = next[idx];
        const prices = calculateOtherQtyPrice(updatedQty);
        next[idx] = { ...updatedQty, price: prices.base };
      }
      
      return next;
    });

  // Calculate price for other quantity based on base product
  const calculateOtherQtyPrice = (otherQty: OtherQty) => {
    const baseProduct = formData.products.find(p => p.productName === otherQty.productName);
    if (!baseProduct || !baseProduct.quantity || !otherQty.quantity) return { base: 0, vat: 0, total: 0 };

    // Calculate price based on the ratio of quantities and include all costs
    const baseCosts = calculateProductCosts(formData.products.indexOf(baseProduct));
    const quantityRatio = otherQty.quantity / baseProduct.quantity;
    
    const basePrice = baseCosts.subtotal * quantityRatio;
    const vat = basePrice * 0.05;
    const total = basePrice + vat;
    
    return { base: basePrice, vat, total };
  };



  const summaryTotals = calculateSummaryTotals();

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="text-center space-y-3">
        <h3 className="text-3xl font-bold text-slate-900">
          Quotation Summary
        </h3>
        <p className="text-slate-600 text-lg">
          Review and finalize your printing quote details
        </p>
      </div>

      {/* Quote To Section */}
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
            <h4 className="text-2xl font-bold text-slate-800">Quote To:</h4>
          </div>
          <div className="flex items-center space-x-3">
            <span className="text-sm text-slate-500 font-medium">Quote ID:</span>
            <div className="px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 text-blue-800 font-mono font-semibold rounded-xl text-sm border border-blue-200">
              {formData.client.companyName ? `Q-${Date.now().toString().slice(-6)}` : 'Pending'}
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Customer Details */}
          <div className="space-y-5">
            <div className="flex items-center space-x-3 mb-4">
              <h5 className="text-lg font-semibold text-slate-700">Customer Details</h5>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start py-3 border-b border-slate-100">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Company</span>
                <span className="font-semibold text-slate-800 text-left ml-4 break-words">
                  {formData.client.clientType === "Company" ? (formData.client.companyName || 'Not specified') : 'Individual Client'}
                </span>
              </div>
              
              <div className="flex items-start py-3 border-b border-slate-100">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Contact Person</span>
                <span className="font-semibold text-slate-800 text-left ml-4 break-words">
                  {formData.client.contactPerson || `${formData.client.firstName || ''} ${formData.client.lastName || ''}`.trim() || 'Not specified'}
                </span>
              </div>
              
              <div className="flex items-start py-3 border-b border-slate-100">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Email</span>
                <span className="font-semibold text-slate-800 text-left ml-4 break-words">
                  {formData.client.email || 'Not specified'}
                </span>
              </div>
              
              <div className="flex items-start py-3">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Phone</span>
                <span className="font-semibold text-slate-800 text-left ml-4 break-words">
                  {formData.client.countryCode && formData.client.phone 
                    ? `${formData.client.countryCode} ${formData.client.phone}` 
                    : 'Not specified'}
                </span>
              </div>
            </div>
          </div>

          {/* Quote Details */}
          <div className="space-y-5">
            <div className="flex items-center space-x-3 mb-4">
              <h5 className="text-lg font-semibold text-slate-700">Quote Details</h5>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start py-3 border-b border-slate-100">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Client Type</span>
                <span className="font-semibold text-slate-800 text-left ml-4 capitalize">
                  {formData.client.clientType || 'Not specified'}
                </span>
              </div>
              
              {formData.client.role && (
                <div className="flex items-start py-3 border-b border-slate-100">
                  <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Role/Designation</span>
                  <span className="font-semibold text-slate-800 text-left ml-4 break-words">
                    {formData.client.role}
                  </span>
                </div>
              )}
              
              <div className="flex items-start py-3 border-b border-slate-100">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Quote Date</span>
                <span className="font-semibold text-slate-800 text-left ml-4">
                  {new Date().toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </span>
              </div>
              
              <div className="flex items-start py-3">
                <span className="text-sm font-medium text-slate-600 w-32 flex-shrink-0">Status</span>
                <span className="px-3 py-1.5 text-xs font-semibold rounded-full bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 border border-blue-300 ml-4">
                  Draft
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Price summary */}
      <div className="bg-white rounded-2xl border-0 shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-xl font-semibold text-slate-800 flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
            Price Summary
          </h4>
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-200">
          <Table>
            <TableHeader className="bg-gradient-to-r from-slate-50 to-blue-50">
              <TableRow className="border-slate-200">
                <TableHead className="text-slate-700 font-semibold py-4 px-6 w-12">
                  <Checkbox
                    checked={includedProducts.size === formData.products.length}
                    onCheckedChange={(checked) => {
                      if (Boolean(checked)) {
                        setIncludedProducts(new Set(formData.products.map((_, index) => index)));
                      } else {
                        setIncludedProducts(new Set());
                      }
                    }}
                  />
                </TableHead>
                <TableHead className="text-slate-700 font-semibold py-4 px-6">Product Name</TableHead>
                <TableHead className="text-slate-700 font-semibold py-4 px-6">Quantity</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Paper Cost</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Plates Cost</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Finishing Cost</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Subtotal</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Margin (15%)</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">VAT (5%)</TableHead>
                <TableHead className="text-right text-slate-700 font-semibold py-4 px-6">Total Price</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {formData.products.map((product, index) => {
                const costs = calculateProductCosts(index);
                const isIncluded = includedProducts.has(index);
                
                return (
                  <TableRow key={index} className="border-slate-200 hover:bg-slate-50/50 transition-colors">
                    <TableCell className="py-4 px-6">
                      <Checkbox
                        checked={isIncluded}
                        onCheckedChange={() => toggleProductInclusion(index)}
                      />
                    </TableCell>
                    <TableCell className="font-medium text-slate-800 py-4 px-6">
                      {product.productName}
                    </TableCell>
                    <TableCell className="text-slate-700 py-4 px-6">
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                        {product.quantity || 0}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6 font-medium">
                      {isIncluded ? currency(costs.paperCost) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6 font-medium">
                      {isIncluded ? currency(costs.platesCost) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6 font-medium">
                      {isIncluded ? currency(costs.finishingCost) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6 font-medium">
                      {isIncluded ? currency(costs.subtotal) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6 font-medium">
                      {isIncluded ? currency(costs.marginAmount) : "—"}
                    </TableCell>
                    <TableCell className="text-right text-slate-700 py-4 px-6">
                      {isIncluded ? (
                        <span className="text-green-600 font-medium">{currency(costs.vat)}</span>
                      ) : "—"}
                    </TableCell>
                    <TableCell className="text-right py-4 px-6">
                      {isIncluded ? (
                        <span className="text-lg font-bold text-blue-600">{currency(costs.total)}</span>
                      ) : "—"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* Cost Breakdown Summary */}
        <div className="mt-8 space-y-4">
          <div className="bg-gradient-to-r from-slate-50 to-blue-50 rounded-2xl p-8 border border-blue-200 shadow-lg">
            <h5 className="text-xl font-bold text-slate-800 mb-6 flex items-center justify-center">
              <Calculator className="w-6 h-6 mr-3 text-blue-600" />
              Cost Breakdown Summary
            </h5>
            
            {/* Cost Categories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {/* Paper Cost */}
              <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-sm font-medium text-slate-600">Paper Cost</span>
                  </div>
                  <Package className="w-5 h-5 text-blue-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800">{currency(summaryTotals.totalPaperCost)}</div>
                <div className="text-xs text-slate-500 mt-1">Based on sheets & paper type</div>
              </div>

              {/* Plates Cost */}
              <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                    <span className="text-sm font-medium text-slate-600">Plates Cost</span>
                  </div>
                  <Settings className="w-5 h-5 text-purple-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800">{currency(summaryTotals.totalPlatesCost)}</div>
                <div className="text-xs text-slate-500 mt-1">Printing plates setup</div>
              </div>

              {/* Finishing Cost */}
              <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                    <span className="text-sm font-medium text-slate-600">Finishing Cost</span>
                  </div>
                  <Settings className="w-5 h-5 text-green-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800">{currency(summaryTotals.totalFinishingCost)}</div>
                <div className="text-xs text-slate-500 mt-1">UV, lamination & special effects</div>
              </div>

              {/* Margin */}
              <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
                    <span className="text-sm font-medium text-slate-600">Margin (15%)</span>
                  </div>
                  <Percent className="w-5 h-5 text-orange-500" />
                </div>
                <div className="text-2xl font-bold text-slate-800">{currency(summaryTotals.totalMarginAmount)}</div>
                <div className="text-xs text-slate-500 mt-1">Standard business margin</div>
              </div>
            </div>

            {/* Cost Breakdown Details */}
            <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
              <h6 className="text-lg font-semibold text-slate-700 mb-4 flex items-center">
                <Calculator className="w-4 h-4 mr-2 text-slate-600" />
                Detailed Breakdown
              </h6>
              
              <div className="space-y-3">
                {/* Paper Cost Detail */}
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                    <span className="text-slate-600">Paper & Materials</span>
                  </div>
                  <span className="font-semibold text-slate-800">{currency(summaryTotals.totalPaperCost)}</span>
                </div>

                {/* Plates Cost Detail */}
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
                    <span className="text-slate-600">Printing Plates</span>
                  </div>
                  <span className="font-semibold text-slate-800">{currency(summaryTotals.totalPlatesCost)}</span>
                </div>

                {/* Finishing Cost Detail */}
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                    <span className="text-slate-600">Finishing Services</span>
                  </div>
                  <span className="font-semibold text-slate-800">{currency(summaryTotals.totalFinishingCost)}</span>
                </div>

                {/* Subtotal before margin */}
                <div className="flex justify-between items-center py-3 border-b border-slate-200">
                  <span className="text-slate-600">Subtotal (Before Margin)</span>
                  <span className="font-semibold text-slate-800">{currency(summaryTotals.totalSubtotal)}</span>
                </div>

                {/* Margin */}
                <div className="flex justify-between items-center py-2 border-b-2 border-slate-200">
                  <span className="text-lg font-semibold text-slate-700">Margin (15%)</span>
                  <span className="text-lg font-bold text-orange-600">{currency(summaryTotals.totalMarginAmount)}</span>
                </div>

                {/* Subtotal after margin */}
                <div className="flex justify-between items-center py-3 border-b-2 border-slate-200">
                  <span className="text-lg font-semibold text-slate-700">Subtotal (After Margin)</span>
                  <span className="text-lg font-bold text-slate-800">{currency(summaryTotals.totalSubtotal + summaryTotals.totalMarginAmount)}</span>
                </div>

                {/* VAT */}
                <div className="flex justify-between items-center py-2">
                  <span className="text-slate-600">VAT (5%)</span>
                  <span className="font-semibold text-green-600">{currency(summaryTotals.totalVAT)}</span>
                </div>
              </div>
            </div>

            {/* Grand Total */}
            <div className="mt-6 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-blue-100 mb-1">Total Amount</div>
                  <div className="text-2xl font-bold">Grand Total</div>
                  {discount.isApplied && discount.percentage > 0 && (
                    <div className="text-sm text-blue-100 mt-2">
                      Includes {discount.percentage}% discount
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-4xl font-bold">{currency(summaryTotals.finalTotal)}</div>
                  <div className="text-sm text-blue-100 mt-1">
                    {discount.isApplied && discount.percentage > 0 
                      ? `After ${discount.percentage}% discount`
                      : 'Including VAT & 15% margin'
                    }
                  </div>
                </div>
              </div>
            </div>

            {/* Additional Info */}
            <div className="mt-4 text-center">
              <div className="text-xs text-slate-500">
                * All prices are in USD and include applicable taxes
              </div>
              <div className="text-xs text-slate-500 mt-1">
                ** Quote valid for 30 days from date of issue
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Discount Management Section */}
      <div className="bg-white rounded-2xl border-0 shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-xl font-semibold text-slate-800 flex items-center">
            <div className="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
            Discount Management
          </h4>
        </div>

        <div className="space-y-6">
          {/* Discount Toggle and Percentage */}
          <div className="flex items-center space-x-4">
            <Checkbox
              checked={discount.isApplied}
              onCheckedChange={(checked) => {
                setDiscount(prev => ({
                  ...prev,
                  isApplied: Boolean(checked),
                  percentage: Boolean(checked) ? prev.percentage : 0,
                  amount: Boolean(checked) ? prev.amount : 0
                }));
              }}
            />
            <Label className="text-lg font-medium text-slate-700">Apply Discount</Label>
          </div>

          {discount.isApplied && (
            <div className="space-y-6">
              {/* Discount Percentage Input */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">
                    Discount Percentage
                  </Label>
                  <div className="relative">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={discount.percentage || ''}
                      onChange={(e) => {
                        const inputValue = e.target.value;
                        const percentage = inputValue === '' ? 0 : Number(inputValue);
                        // Calculate discount amount based on current grand total
                        const currentGrandTotal = calculateGrandTotalWithoutDiscount();
                        const amount = (currentGrandTotal * percentage) / 100;
                        setDiscount(prev => ({
                          ...prev,
                          percentage,
                          amount
                        }));
                      }}
                      onBlur={(e) => {
                        // Ensure the value is properly formatted on blur
                        const percentage = Number(e.target.value) || 0;
                        if (percentage !== discount.percentage) {
                          const currentGrandTotal = calculateGrandTotalWithoutDiscount();
                          const amount = (currentGrandTotal * percentage) / 100;
                          setDiscount(prev => ({
                            ...prev,
                            percentage,
                            amount
                          }));
                        }
                      }}
                      className="border-slate-300 focus:border-orange-500 focus:ring-orange-500 rounded-xl pr-12"
                      placeholder="0.0"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <Percent className="h-5 w-5 text-slate-400" />
                    </div>
                  </div>
                  
                  {/* Quick Discount Buttons */}
                  <div className="mt-2 flex flex-wrap gap-2">
                    {[5, 10, 15, 20, 25].map((percent) => (
                      <Button
                        key={percent}
                        type="button"
                        variant="outline"
                        size="sm"
                        className={`text-xs px-3 py-1 h-8 ${
                          discount.percentage === percent
                            ? 'bg-orange-100 border-orange-300 text-orange-700'
                            : 'border-slate-300 text-slate-600 hover:bg-slate-50'
                        }`}
                        onClick={() => {
                          const currentGrandTotal = calculateGrandTotalWithoutDiscount();
                          const amount = (currentGrandTotal * percent) / 100;
                          setDiscount(prev => ({
                            ...prev,
                            percentage: percent,
                            amount
                          }));
                        }}
                      >
                        {percent}%
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium text-slate-700 mb-2 block">
                    Discount Amount
                  </Label>
                  <div className="relative">
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={discount.amount}
                      readOnly
                      className="bg-slate-100 border-slate-300 rounded-xl pr-12 font-medium"
                    />
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <DollarSign className="h-5 w-5 text-slate-400" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Discount Approval Section */}
              <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-6 border border-orange-200">
                <h5 className="text-lg font-semibold text-orange-800 mb-4 flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  Discount Approval Required
                </h5>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-medium text-orange-700 mb-2 block">
                      Approved By
                    </Label>
                    <Select
                      value={discountApproval.approvedBy}
                      onValueChange={(value) =>
                        setDiscountApproval(prev => ({
                          ...prev,
                          approvedBy: value
                        }))
                      }
                    >
                      <SelectTrigger className="border-orange-300 focus:border-orange-500 focus:ring-orange-500 rounded-xl bg-white">
                        <SelectValue placeholder="Select approver" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border border-slate-200 shadow-lg">
                        {availableApprovers.map((approver) => (
                          <SelectItem key={approver} value={approver} className="hover:bg-slate-50">
                            {approver}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-orange-700 mb-2 block">
                      Reason for Discount
                    </Label>
                    <Input
                      type="text"
                      value={discountApproval.reason}
                      onChange={(e) =>
                        setDiscountApproval(prev => ({
                          ...prev,
                          reason: e.target.value
                        }))
                      }
                      className="border-orange-300 focus:border-orange-500 focus:ring-orange-500 rounded-xl"
                      placeholder="e.g., Bulk order, Loyal customer, etc."
                    />
                  </div>
                </div>

                {discountApproval.approvedBy && discountApproval.reason && (
                  <div className="mt-4 p-4 bg-white rounded-lg border border-orange-200">
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-orange-700">
                        <span className="font-medium">Approved by:</span> {discountApproval.approvedBy}
                      </div>
                      <div className="text-sm text-orange-700">
                        <span className="font-medium">Date:</span> {discountApproval.approvedAt.toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-2 text-sm text-orange-700">
                      <span className="font-medium">Reason:</span> {discountApproval.reason}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Discount Summary */}
          {discount.isApplied && discount.percentage > 0 && (
            <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
              <h5 className="text-lg font-semibold text-green-800 mb-4 flex items-center">
                <Calculator className="w-5 h-5 mr-2" />
                Discount Summary
              </h5>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white rounded-lg p-4 border border-green-200">
                  <div className="text-sm text-green-600 mb-1">Original Total</div>
                  <div className="text-xl font-bold text-slate-800">{currency(summaryTotals.grandTotal)}</div>
                </div>
                
                <div className="bg-white rounded-lg p-4 border border-green-200">
                  <div className="text-sm text-green-600 mb-1">Discount ({discount.percentage}%)</div>
                  <div className="text-xl font-bold text-red-600">-{currency(summaryTotals.discountAmount)}</div>
                </div>
                
                <div className="bg-white rounded-lg p-4 border border-green-200">
                  <div className="text-sm text-green-600 mb-1">Final Total</div>
                  <div className="text-xl font-bold text-green-600">{currency(summaryTotals.finalTotal)}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Other quantities */}
      <div className="bg-white rounded-2xl border-0 shadow-lg p-8">
        <div className="flex justify-between items-center mb-6">
          <h4 className="text-xl font-semibold text-slate-800 flex items-center">
            <div className="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
            Supplementary Information: Other Quantities
          </h4>
        </div>
        
        <Button 
          variant="outline" 
          className="mb-6 border-blue-500 text-blue-600 hover:bg-blue-50 hover:border-blue-600 rounded-xl px-6 py-3 transition-all duration-200" 
          size="sm" 
          onClick={addOtherQty}
          disabled={includedProducts.size === 0}
        >
          <Plus className="h-5 w-5 mr-2" />
          Add Other Quantities
        </Button>

        <div className="space-y-6">
          {otherQuantities.length === 0 && (
            <div className="text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-300">
              <div className="text-slate-400 mb-2 text-4xl">📋</div>
              <p className="text-slate-600 font-medium">No other quantities added yet</p>
              <p className="text-slate-500 text-sm mt-1">Click the button above to add supplementary items</p>
            </div>
          )}

          {otherQuantities.map((row, idx) => {
            const prices = calculateOtherQtyPrice(row);

            return (
              <div
                key={idx}
                className="bg-gradient-to-r from-slate-50 to-blue-50 rounded-2xl p-6 border border-slate-200 hover:shadow-md transition-all duration-200"
              >
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                  <div className="md:col-span-3">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Product Name</Label>
                    <Select
                      value={row.productName}
                      onValueChange={(value) =>
                        updateOtherQty(idx, { productName: value })
                      }
                    >
                      <SelectTrigger className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-xl">
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        {formData.products
                          .filter((_, index) => includedProducts.has(index))
                          .map((product, productIndex) => (
                            <SelectItem key={productIndex} value={product.productName}>
                              {product.productName}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Quantity</Label>
                    <Input
                      type="number"
                      min={1}
                      value={row.quantity}
                      onChange={(e) =>
                        updateOtherQty(idx, {
                          quantity:
                            e.target.value === "" ? "" : Number(e.target.value),
                        })
                      }
                      className="border-slate-300 focus:border-blue-500 focus:ring-blue-500 rounded-xl"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Base Price</Label>
                    <Input
                      readOnly
                      className="bg-slate-100 border-slate-300 rounded-xl font-medium"
                      value={currency(prices.base)}
                    />
                  </div>

                  <div className="md:col-span-3 grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-slate-700 mb-2 block">VAT (5%)</Label>
                      <Input
                        readOnly
                        className="bg-slate-100 border-slate-300 rounded-xl font-medium text-green-600"
                        value={currency(prices.vat)}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-slate-700 mb-2 block">Total</Label>
                      <Input
                        readOnly
                        className="bg-slate-100 border-slate-300 rounded-xl font-bold text-blue-600"
                        value={currency(prices.total)}
                      />
                    </div>
                  </div>

                  <div className="md:col-span-1 flex flex-col items-end">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Action</Label>
                    <Button
                      variant="ghost"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl p-3 transition-all duration-200"
                      onClick={() => removeOtherQty(idx)}
                      title="Remove"
                    >
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Download Options */}
      <div className="bg-white rounded-2xl border-0 shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-xl font-semibold text-slate-800 flex items-center">
            <div className="w-3 h-3 bg-indigo-500 rounded-full mr-3"></div>
            Download Options
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Customer Copy Download */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200 hover:shadow-md transition-all duration-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                <span className="text-lg font-semibold text-green-800">Customer Copy</span>
              </div>
              <Download className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-green-700 mb-4 text-sm">
              Professional quote document suitable for customer presentation
            </p>
            <Button
              className="w-full bg-green-600 hover:bg-green-700 text-white rounded-xl py-3 shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => {
                // TODO: Implement customer PDF download
                console.log('Downloading customer copy...');
              }}
            >
              <Download className="w-4 h-4 mr-2" />
              Download Customer Copy
            </Button>
          </div>

          {/* Operations Copy Download */}
          <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl p-6 border border-orange-200 hover:shadow-md transition-all duration-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
                <span className="text-lg font-semibold text-orange-800">Operations Copy</span>
              </div>
              <Settings className="w-6 h-6 text-orange-600" />
            </div>
            <p className="text-orange-700 mb-4 text-sm">
              Detailed technical specifications for production team
            </p>
            <Button
              className="w-full bg-orange-600 hover:bg-orange-700 text-white rounded-xl py-3 shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => {
                // TODO: Implement operations PDF download
                console.log('Downloading operations copy...');
              }}
            >
              <Download className="w-4 h-4 mr-2" />
              Download Operations Copy
            </Button>
          </div>
        </div>
      </div>

      {/* Summary Footer */}
      <div className="bg-gradient-to-r from-slate-50 to-blue-50 rounded-2xl border border-slate-200 p-6">
        {/* Validation Errors Display */}
        {validationErrors.length > 0 && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4">
            <h4 className="text-lg font-semibold text-red-800 mb-3 flex items-center">
              ⚠️ Please fix the following issues before saving:
            </h4>
            <ul className="space-y-2">
              {validationErrors.map((error, index) => (
                <li key={index} className="text-red-700 flex items-center">
                  <span className="w-2 h-2 bg-red-500 rounded-full mr-3"></span>
                  {error}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Action Selection */}
        <div className="mb-6">
          <h4 className="text-lg font-semibold text-slate-800 mb-4 text-center">Choose Your Action</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              variant={submissionAction === 'Save Draft' ? 'default' : 'outline'}
              className={`h-12 ${
                submissionAction === 'Save Draft' 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : 'border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
              onClick={() => setSubmissionAction('Save Draft')}
            >
              💾 Save Draft
            </Button>
            
            <Button
              variant={submissionAction === 'Send for Approval' ? 'default' : 'outline'}
              className={`h-12 ${
                submissionAction === 'Send for Approval' 
                  ? 'bg-orange-600 hover:bg-orange-700 text-white' 
                  : 'border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
              onClick={() => setSubmissionAction('Send for Approval')}
            >
              📋 Send for Approval
            </Button>
            
            <Button
              variant={submissionAction === 'Send to Customer' ? 'default' : 'outline'}
              className={`h-12 ${
                submissionAction === 'Send to Customer' 
                  ? 'bg-green-600 hover:bg-green-700 text-white' 
                  : 'border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
              onClick={() => setSubmissionAction('Send to Customer')}
            >
              📧 Send to Customer
            </Button>
          </div>
        </div>

        {/* Conditional Forms Based on Action */}
        {submissionAction === 'Send for Approval' && (
          <div className="mb-6 bg-orange-50 border border-orange-200 rounded-xl p-6">
            <h5 className="text-lg font-semibold text-orange-800 mb-4 flex items-center">
              📋 Approval Request Details
            </h5>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-orange-700 mb-2 block">
                  Approval Notes
                </Label>
                <textarea
                  value={quoteApproval.approvalNotes || ''}
                  onChange={(e) => setQuoteApproval(prev => ({
                    ...prev,
                    approvalNotes: e.target.value
                  }))}
                  className="w-full border-orange-300 focus:border-orange-500 focus:ring-orange-500 rounded-xl p-3 resize-none"
                  rows={3}
                  placeholder="Add any notes or context for the approval request..."
                />
              </div>
              <div className="text-sm text-orange-600">
                <strong>Note:</strong> This quote will be marked as "Pending Approval" and will require manager approval before it can be sent to the customer.
              </div>
            </div>
          </div>
        )}

        {submissionAction === 'Send to Customer' && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-xl p-6">
            <h5 className="text-lg font-semibold text-green-800 mb-4 flex items-center">
              📧 Customer Email Details
            </h5>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium text-green-700 mb-2 block">
                  To (Primary Email)
                </Label>
                <Input
                  type="email"
                  value={quoteEmail.to}
                  onChange={(e) => setQuoteEmail(prev => ({
                    ...prev,
                    to: e.target.value
                  }))}
                  className="border-green-300 focus:border-green-500 focus:ring-green-500 rounded-xl"
                  placeholder="customer@example.com"
                />
              </div>
              
              <div>
                <Label className="text-sm font-medium text-green-700 mb-2 block">
                  CC (Additional Emails)
                </Label>
                <Input
                  type="text"
                  value={quoteEmail.cc.join(', ')}
                  onChange={(e) => setQuoteEmail(prev => ({
                    ...prev,
                    cc: e.target.value.split(',').map(email => email.trim()).filter(Boolean)
                  }))}
                  className="border-green-300 focus:border-green-500 focus:ring-green-500 rounded-xl"
                  placeholder="cc1@example.com, cc2@example.com"
                />
              </div>
              
              <div>
                <Label className="text-sm font-medium text-green-700 mb-2 block">
                  Subject Line
                </Label>
                <Input
                  type="text"
                  value={quoteEmail.subject}
                  onChange={(e) => setQuoteEmail(prev => ({
                    ...prev,
                    subject: e.target.value
                  }))}
                  className="border-green-300 focus:border-green-500 focus:ring-green-500 rounded-xl"
                  placeholder="Printing Quote - Your Company"
                />
              </div>
              
              <div>
                <Label className="text-sm font-medium text-green-700 mb-2 block">
                  Email Body
                </Label>
                <textarea
                  value={quoteEmail.body}
                  onChange={(e) => setQuoteEmail(prev => ({
                    ...prev,
                    body: e.target.value
                  }))}
                  className="w-full border-green-300 focus:border-green-500 focus:ring-green-500 rounded-xl p-3 resize-none"
                  rows={4}
                  placeholder="Write your email message here..."
                />
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-medium text-green-700 mb-2 block">
                  Attachments
                </Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={quoteEmail.attachments?.customerCopy}
                      onCheckedChange={(checked) => setQuoteEmail(prev => ({
                        ...prev,
                        attachments: {
                          ...prev.attachments!,
                          customerCopy: Boolean(checked)
                        }
                      }))}
                    />
                    <Label className="text-sm text-green-700">Include Customer Copy</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      checked={quoteEmail.attachments?.operationsCopy}
                      onCheckedChange={(checked) => setQuoteEmail(prev => ({
                        ...prev,
                        attachments: {
                          ...prev.attachments!,
                          operationsCopy: Boolean(checked)
                        }
                      }))}
                    />
                    <Label className="text-sm text-green-700">Include Operations Copy</Label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="text-center space-y-3">
          <h4 className="text-lg font-semibold text-slate-800">
            {submissionAction === 'Save Draft' && 'Ready to Save?'}
            {submissionAction === 'Send for Approval' && 'Ready to Send for Approval?'}
            {submissionAction === 'Send to Customer' && 'Ready to Send to Customer?'}
          </h4>
          <p className="text-slate-600">
            {submissionAction === 'Save Draft' && 'Review all details above and click the Save Quote button when ready to proceed'}
            {submissionAction === 'Send for Approval' && 'This quote will be sent to management for approval before customer submission'}
            {submissionAction === 'Send to Customer' && 'This quote will be emailed directly to the customer with the specified attachments'}
          </p>
          
          {/* Final Action Button */}
          <div className="mt-6">
            <Button
              onClick={handleSaveWithValidation}
              className={`h-14 px-8 text-lg font-semibold rounded-xl ${
                submissionAction === 'Save Draft' 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : submissionAction === 'Send for Approval'
                  ? 'bg-orange-600 hover:bg-orange-700 text-white'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
              disabled={validationErrors.length > 0}
            >
              {submissionAction === 'Save Draft' && '💾 Save Quote'}
              {submissionAction === 'Send for Approval' && '📋 Send for Approval'}
              {submissionAction === 'Send to Customer' && '📧 Send to Customer'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Step5Quotation;